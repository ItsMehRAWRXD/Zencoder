#include <iostream>
#include "menu.h"
#include "packer.h"
#include <mutex>
#include <map>
#include <set>
#include <filesystem>

#ifdef _WIN32
#include <windows.h>
#else
using DWORD = unsigned long;
using SIZE_T = std::size_t;
#endif

// Global variables needed by the menu
std::mutex g_protectedRegionsMutex;
std::map<DWORD, std::set<std::pair<uintptr_t, uintptr_t>>> g_protectedRegions;

// Register a memory region to be protected
void registerProtectedMemoryRegion(DWORD processId, void* startAddress, SIZE_T size) {
    std::lock_guard<std::mutex> lock(g_protectedRegionsMutex);
    g_protectedRegions[processId].insert(std::make_pair(
        reinterpret_cast<uintptr_t>(startAddress),
        reinterpret_cast<uintptr_t>(startAddress) + size
    ));
    
    std::cout << "[PROTECTION] Registered memory region " << std::hex 
              << startAddress << "-" << (uintptr_t)startAddress + size 
              << std::dec << " for process " << processId << std::endl;
}

static bool handleCommandLine(int argc, char** argv) {
    if (argc <= 1) return false;
    // Mode: add stubs
    if (std::string(argv[1]) == "--add-stubs" && argc >= 3) {
        std::string target = argv[2];
        int count = 1; size_t size = 256; std::string prefix = "STUB_";
        for (int i = 3; i < argc; ++i) {
            std::string a = argv[i];
            if (a == "--count" && i + 1 < argc) { count = std::stoi(argv[++i]); }
            else if (a == "--size" && i + 1 < argc) { size = static_cast<size_t>(std::stoul(argv[++i])); }
            else if (a == "--prefix" && i + 1 < argc) { prefix = argv[++i]; }
        }
        Z3Processor p; bool ok = p.addRandomStubs(target, count, prefix, size);
        std::cout << (ok ? "Stubs appended." : "Failed to append stubs.") << std::endl;
        return true;
    }
    // If files were dropped on the exe, pack them to out.z3 in cwd
    std::vector<std::string> inputs;
    for (int i = 1; i < argc; ++i) {
        inputs.emplace_back(argv[i]);
    }
    if (!inputs.empty()) {
        Z3Processor p;
        p.setupMode(Fx7z9Process::Qx3r); // default XOR
        std::string out = std::filesystem::current_path().append("packed.z3").string();
        bool ok = p.runTask42(inputs, out);
        std::cout << (ok ? ("Packed to " + out) : std::string("Failed to pack.")) << std::endl;
        return true;
    }
    return false;
}

int main(int argc, char** argv) {
    if (handleCommandLine(argc, argv)) return 0;

    std::cout << "==================================\n";
    std::cout << "      Advanced Crypto Utility     \n";
    std::cout << "==================================\n";
    std::cout << "This tool provides encryption, packing, and PE manipulation capabilities.\n";
    
    while (true) {
        displayMenu();
        int choice;
        std::cin >> choice;

        if (choice == 0) {
            std::cout << "Exiting the application." << std::endl;
            break;
        }

        handleMenuChoice(choice);
    }
    return 0;
}