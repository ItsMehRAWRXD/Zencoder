#pragma once

void rc4Init();