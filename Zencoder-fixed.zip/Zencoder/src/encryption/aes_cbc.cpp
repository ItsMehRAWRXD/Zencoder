#include "aes_cbc.h"

void aesCbcInit() {}