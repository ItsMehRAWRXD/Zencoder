#include "chacha20.h"

void chacha20Init() {}