#include "twofish.h"

void twofishInit() {}