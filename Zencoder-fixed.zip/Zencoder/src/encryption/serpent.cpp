#include "serpent.h"

void serpentInit() {}