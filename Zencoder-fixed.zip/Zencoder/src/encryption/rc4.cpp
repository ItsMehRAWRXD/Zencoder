#include "rc4.h"

void rc4Init() {}