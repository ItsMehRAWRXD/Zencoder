#pragma once

void aesCtrInit();