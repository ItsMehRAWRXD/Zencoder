#include "camellia.h"

void camelliaInit() {}