#pragma once

void chacha20Init();