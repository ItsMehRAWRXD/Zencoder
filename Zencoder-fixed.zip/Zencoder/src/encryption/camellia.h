#pragma once

void camelliaInit();