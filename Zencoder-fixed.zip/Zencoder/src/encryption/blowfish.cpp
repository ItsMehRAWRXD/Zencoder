#include "blowfish.h"

void blowfishInit() {}