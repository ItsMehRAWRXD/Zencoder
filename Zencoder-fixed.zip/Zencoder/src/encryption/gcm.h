#pragma once

void gcmInit();