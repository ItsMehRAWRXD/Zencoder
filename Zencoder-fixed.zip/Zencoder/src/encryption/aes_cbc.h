#pragma once

void aesCbcInit();