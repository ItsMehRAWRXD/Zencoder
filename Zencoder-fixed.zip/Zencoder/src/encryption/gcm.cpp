#include "gcm.h"

void gcmInit() {
    // no-op stub
}