#pragma once

void encryptionBaseInit();