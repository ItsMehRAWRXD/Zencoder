#pragma once

void serpentInit();