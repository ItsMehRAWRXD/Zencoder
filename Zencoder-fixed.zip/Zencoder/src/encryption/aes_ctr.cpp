#include "aes_ctr.h"

void aesCtrInit() {}