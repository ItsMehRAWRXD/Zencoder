#pragma once

void blowfishInit();