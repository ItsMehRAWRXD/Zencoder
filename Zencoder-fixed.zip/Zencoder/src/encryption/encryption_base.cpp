#include "encryption_base.h"

void encryptionBaseInit() {
    // no-op stub for now
}