#pragma once

void twofishInit();