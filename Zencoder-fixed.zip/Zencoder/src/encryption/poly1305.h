#pragma once

void poly1305Init();