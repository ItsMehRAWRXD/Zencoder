#include "poly1305.h"

void poly1305Init() {}