#pragma once

#include <string>
#include <vector>

bool readFileToBuffer(const std::string& path, std::vector<unsigned char>& outBuffer);
bool writeBufferToFile(const std::string& path, const std::vector<unsigned char>& buffer);