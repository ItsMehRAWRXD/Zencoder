#include "file_utils.h"
#include <fstream>
#include <vector>

bool readFileToBuffer(const std::string& path, std::vector<unsigned char>& outBuffer) {
    std::ifstream in(path, std::ios::binary);
    if (!in) return false;
    in.seekg(0, std::ios::end);
    std::streamsize size = in.tellg();
    in.seekg(0, std::ios::beg);
    outBuffer.resize(static_cast<size_t>(size));
    return in.read(reinterpret_cast<char*>(outBuffer.data()), size).good();
}

bool writeBufferToFile(const std::string& path, const std::vector<unsigned char>& buffer) {
    std::ofstream out(path, std::ios::binary);
    if (!out) return false;
    out.write(reinterpret_cast<const char*>(buffer.data()), static_cast<std::streamsize>(buffer.size()));
    return out.good();
}