#include "../include/packer.h"
#include "menu.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <filesystem>
#include <random>
#include <algorithm>
#include <cstring>

#ifdef _WIN32
#include <windows.h>
#else
using DWORD = unsigned long;
using SIZE_T = std::size_t;
#endif

#ifdef HAVE_OPENSSL
#include <openssl/evp.h>
#include <openssl/rand.h>
#endif

#ifdef HAVE_CRYPTOPP
#include <cryptopp/twofish.h>
#include <cryptopp/serpent.h>
#include <cryptopp/modes.h>
#include <cryptopp/filters.h>
#endif

// External function for memory protection
extern void registerProtectedMemoryRegion(DWORD processId, void* startAddress, SIZE_T size);

// File signature and format constants
const uint32_t Z3_FILE_SIGNATURE = 0x3A334E5A; // "Z3:" in little-endian
const uint8_t Z3_FORMAT_VERSION = 0x01;

// Implementation of AES and other crypto algorithms would be here
// For brevity, we'll use placeholder implementations

Z3Processor::Z3Processor() : m_processMode(Fx7z9Process::D4t0) {
    // Initialize with default no-encryption mode
}

Z3Processor::~Z3Processor() {
    // Clean up any resources
    // Securely wipe key material from memory
    if (!m_seedValue.empty()) {
        std::fill(m_seedValue.begin(), m_seedValue.end(), 0);
    }
}

void Z3Processor::setupMode(Fx7z9Process mode) {
    m_processMode = mode;
}

void Z3Processor::setupSeed(const std::vector<uint8_t>& seed) {
    if (!seed.empty()) {
        m_seedValue = seed;
    } else {
        // Generate a cryptographically strong random seed
        std::random_device rd;
        std::vector<uint8_t> entropy(32);
        
        for (size_t i = 0; i < entropy.size(); ++i) {
            entropy[i] = static_cast<uint8_t>(rd());
        }
        
        std::seed_seq seq(entropy.begin(), entropy.end());
        std::mt19937 gen(seq);
        std::uniform_int_distribution<unsigned> dist(0, 255);
        
        m_seedValue.resize(32);
        for (int i = 0; i < 32; i++) {
            m_seedValue[i] = static_cast<uint8_t>(dist(gen));
        }
    }
    
    #ifdef _WIN32
    try {
        registerProtectedMemoryRegion(GetCurrentProcessId(), m_seedValue.data(), m_seedValue.size());
    } catch (...) {
    }
    #endif
}

Fx7z9Process Z3Processor::getProcessMode() const {
    return m_processMode;
}

bool Z3Processor::runTask42(const std::vector<std::string>& sourceItems, const std::string& outputPath) {
    // Combine multiple files into a single encrypted package
    try {
        std::vector<uint8_t> packageData;
        
        // Add file signature and version
        packageData.push_back((Z3_FILE_SIGNATURE >> 0) & 0xFF);
        packageData.push_back((Z3_FILE_SIGNATURE >> 8) & 0xFF);
        packageData.push_back((Z3_FILE_SIGNATURE >> 16) & 0xFF);
        packageData.push_back((Z3_FILE_SIGNATURE >> 24) & 0xFF);
        packageData.push_back(Z3_FORMAT_VERSION);
        
        // Add encryption mode
        packageData.push_back(static_cast<uint8_t>(m_processMode));
        
        // Number of items
        uint32_t numItems = static_cast<uint32_t>(sourceItems.size());
        packageData.push_back((numItems >> 0) & 0xFF);
        packageData.push_back((numItems >> 8) & 0xFF);
        packageData.push_back((numItems >> 16) & 0xFF);
        packageData.push_back((numItems >> 24) & 0xFF);
        
        // Reserve table
        size_t itemTableOffset = packageData.size();
        for (size_t i = 0; i < numItems; i++) {
            packageData.resize(packageData.size() + 1 + 255 + 4 + 4, 0);
        }
        
        std::vector<std::pair<std::string, std::pair<uint32_t, uint32_t>>> fileEntries;
        size_t dataOffset = packageData.size();
        
        for (const auto& itemPath : sourceItems) {
            std::vector<uint8_t> fileData = loadResource(itemPath);
            if (fileData.empty()) {
                std::cerr << "Failed to read file: " << itemPath << std::endl;
                continue;
            }
            
            std::string filename = std::filesystem::path(itemPath).filename().string();
            
            if (m_processMode != Fx7z9Process::D4t0) {
                fileData = processData(fileData, true);
            }
            
            uint32_t fileOffset = static_cast<uint32_t>(packageData.size() - dataOffset);
            uint32_t fileSize = static_cast<uint32_t>(fileData.size());
            fileEntries.push_back(std::make_pair(filename, std::make_pair(fileOffset, fileSize)));
            
            packageData.insert(packageData.end(), fileData.begin(), fileData.end());
        }
        
        // Fill table (simple fixed spans per entry)
        size_t tablePos = itemTableOffset;
        for (const auto& entry : fileEntries) {
            const std::string& filename = entry.first;
            uint32_t fileOffset = entry.second.first;
            uint32_t fileSize = entry.second.second;
            
            packageData[tablePos++] = static_cast<uint8_t>(filename.length());
            for (char c : filename) {
                packageData[tablePos++] = static_cast<uint8_t>(c);
            }
            tablePos = itemTableOffset + 1 + 255; // fixed jump for simplicity
            
            packageData[tablePos++] = (fileOffset >> 0) & 0xFF;
            packageData[tablePos++] = (fileOffset >> 8) & 0xFF;
            packageData[tablePos++] = (fileOffset >> 16) & 0xFF;
            packageData[tablePos++] = (fileOffset >> 24) & 0xFF;
            
            packageData[tablePos++] = (fileSize >> 0) & 0xFF;
            packageData[tablePos++] = (fileSize >> 8) & 0xFF;
            packageData[tablePos++] = (fileSize >> 16) & 0xFF;
            packageData[tablePos++] = (fileSize >> 24) & 0xFF;
            
            itemTableOffset += 1 + 255 + 4 + 4;
        }
        
        std::ofstream outFile(outputPath, std::ios::binary);
        if (!outFile) {
            std::cerr << "Failed to create output file: " << outputPath << std::endl;
            return false;
        }
        outFile.write(reinterpret_cast<const char*>(packageData.data()), packageData.size());
        outFile.close();
        return true;
    } catch (const std::exception& e) {
        std::cerr << "Error in runTask42: " << e.what() << std::endl;
        return false;
    }
}

bool Z3Processor::runTask67(const std::string& inputPath, const std::string& outputDir) {
    // Extract files from an encrypted package
    try {
        std::vector<uint8_t> packageData = loadResource(inputPath);
        if (packageData.empty()) {
            std::cerr << "Failed to read package file: " << inputPath << std::endl;
            return false;
        }
        if (packageData.size() < 10) {
            std::cerr << "Invalid package file: too small" << std::endl;
            return false;
        }
        
        uint32_t signature = 
            (static_cast<uint32_t>(packageData[0]) << 0) |
            (static_cast<uint32_t>(packageData[1]) << 8) |
            (static_cast<uint32_t>(packageData[2]) << 16) |
            (static_cast<uint32_t>(packageData[3]) << 24);
        if (signature != Z3_FILE_SIGNATURE) {
            std::cerr << "Invalid package file: wrong signature" << std::endl;
            return false;
        }
        if (packageData[4] != Z3_FORMAT_VERSION) {
            std::cerr << "Unsupported package format version" << std::endl;
            return false;
        }
        
        Fx7z9Process mode = static_cast<Fx7z9Process>(packageData[5]);
        size_t tablePos = 6;
        uint32_t numItems = 
            (static_cast<uint32_t>(packageData[6]) << 0) |
            (static_cast<uint32_t>(packageData[7]) << 8) |
            (static_cast<uint32_t>(packageData[8]) << 16) |
            (static_cast<uint32_t>(packageData[9]) << 24);
        size_t itemTableOffset = 10;
        size_t dataOffset = itemTableOffset + (1 + 255 + 4 + 4) * numItems;
        
        size_t cursor = dataOffset;
        for (uint32_t i = 0; i < numItems; i++) {
            size_t entryPos = itemTableOffset + i * (1 + 255 + 4 + 4);
            uint8_t nameLen = packageData[entryPos++];
            std::string filename;
            filename.reserve(nameLen);
            for (uint8_t j = 0; j < nameLen; ++j) {
                filename.push_back(static_cast<char>(packageData[entryPos++]));
            }
            entryPos = itemTableOffset + 1 + 255 + i * (1 + 255 + 4 + 4);
            uint32_t fileOffset =
                (static_cast<uint32_t>(packageData[entryPos + 0]) << 0) |
                (static_cast<uint32_t>(packageData[entryPos + 1]) << 8) |
                (static_cast<uint32_t>(packageData[entryPos + 2]) << 16) |
                (static_cast<uint32_t>(packageData[entryPos + 3]) << 24);
            uint32_t fileSize =
                (static_cast<uint32_t>(packageData[entryPos + 4]) << 0) |
                (static_cast<uint32_t>(packageData[entryPos + 5]) << 8) |
                (static_cast<uint32_t>(packageData[entryPos + 6]) << 16) |
                (static_cast<uint32_t>(packageData[entryPos + 7]) << 24);
            
            std::vector<uint8_t> fileData(
                packageData.begin() + dataOffset + fileOffset,
                packageData.begin() + dataOffset + fileOffset + fileSize);
            
            if (mode != Fx7z9Process::D4t0) {
                // decrypt
                Fx7z9Process originalMode = m_processMode;
                m_processMode = mode;
                std::vector<uint8_t> plain = processData(fileData, false);
                m_processMode = originalMode;
                fileData.swap(plain);
            }
            
            std::filesystem::path outPath = std::filesystem::path(outputDir) / filename;
            std::ofstream out(outPath, std::ios::binary);
            if (!out) {
                std::cerr << "Failed to create output: " << outPath.string() << std::endl;
                continue;
            }
            out.write(reinterpret_cast<const char*>(fileData.data()), fileData.size());
            out.close();
        }
        return true;
    } catch (const std::exception& e) {
        std::cerr << "Error in runTask67: " << e.what() << std::endl;
        return false;
    }
}

bool Z3Processor::checkFormat92(const std::string& itemPath) {
    // Check if a file has the correct format
    try {
        std::vector<uint8_t> data = loadResource(itemPath);
        if (data.size() < 10) return false;
        uint32_t signature = 
            (static_cast<uint32_t>(data[0]) << 0) |
            (static_cast<uint32_t>(data[1]) << 8) |
            (static_cast<uint32_t>(data[2]) << 16) |
            (static_cast<uint32_t>(data[3]) << 24);
        return signature == Z3_FILE_SIGNATURE && data[4] == Z3_FORMAT_VERSION;
    } catch (...) {
        return false;
    }
}

bool Z3Processor::task104(const std::string& targetPath, const std::string& label, 
                         const std::vector<uint8_t>& componentData) {
    try {
        // Append a labeled component blob to a file
        std::ofstream out(targetPath, std::ios::binary | std::ios::app);
        if (!out) return false;
        uint8_t len = static_cast<uint8_t>(std::min<size_t>(label.size(), 255));
        out.write(reinterpret_cast<const char*>(&len), 1);
        out.write(label.data(), len);
        uint32_t size = static_cast<uint32_t>(componentData.size());
        out.write(reinterpret_cast<const char*>(&size), 4);
        out.write(reinterpret_cast<const char*>(componentData.data()), componentData.size());
        out.close();
        return true;
    } catch (...) {
        return false;
    }
}

bool Z3Processor::task219(const std::string& targetPath, const std::string& label, 
                         Fx7z9Process mode, const std::vector<uint8_t>& seed) {
    try {
        // Store an encrypted labeled component
        Z3Processor temp;
        temp.setupMode(mode);
        temp.setupSeed(seed);
        std::vector<uint8_t> blob = temp.processData(std::vector<uint8_t>(label.begin(), label.end()), true);
        return task104(targetPath, label, blob);
    } catch (...) {
        return false;
    }
}

bool Z3Processor::task317(const std::string& targetPath) {
    // TODO: Implement PE import table obfuscation.
    // This is a no-op placeholder to keep the pipeline intact without mutating PE structures.
    // A production implementation would parse the PE headers and import directory and then
    // transform or encrypt import descriptors and thunks before re-writing the image.
    try {
        std::vector<uint8_t> peData = loadResource(targetPath);
        if (peData.empty()) {
            std::cerr << "Failed to read PE file: " << targetPath << std::endl;
            return false;
        }
        std::string marker = "IMPORTS_OBFUSCATED";
        std::vector<uint8_t> markerData(marker.begin(), marker.end());
        peData.insert(peData.end(), markerData.begin(), markerData.end());
        return saveResource(targetPath, peData);
    } catch (const std::exception& e) {
        std::cerr << "Error in task317: " << e.what() << std::endl;
        return false;
    }
}

bool Z3Processor::task318(const std::string& targetPath) {
    // TODO: Implement PE export table obfuscation.
    // This is a no-op placeholder to keep the pipeline intact without mutating PE structures.
    // A production implementation would parse the PE headers and export directory
    // and then transform or encrypt the export directory entries before re-writing the image.
    try {
        std::vector<uint8_t> peData = loadResource(targetPath);
        if (peData.empty()) {
            std::cerr << "Failed to read PE file: " << targetPath << std::endl;
            return false;
        }
        std::string marker = "EXPORTS_OBFUSCATED";
        std::vector<uint8_t> markerData(marker.begin(), marker.end());
        peData.insert(peData.end(), markerData.begin(), markerData.end());
        return saveResource(targetPath, peData);
    } catch (const std::exception& e) {
        std::cerr << "Error in task318: " << e.what() << std::endl;
        return false;
    }
}

bool Z3Processor::addRandomStubs(const std::string& targetExePath, int count, const std::string& labelPrefix, size_t stubSizeBytes) {
    if (count <= 0) return true;
    try {
        for (int i = 0; i < count; ++i) {
            // Generate random stub content
            std::vector<uint8_t> stub = getRandomNonce(stubSizeBytes > 0 ? stubSizeBytes : 256);
            // Label prefix + index (max 255 length enforced by task104)
            std::ostringstream oss;
            oss << labelPrefix << i;
            std::string label = oss.str();
            if (!task104(targetExePath, label, stub)) {
                return false;
            }
        }
        return true;
    } catch (...) {
        return false;
    }
}

std::vector<uint8_t> Z3Processor::loadResource(const std::string& path) {
    try {
        std::ifstream file(path, std::ios::binary);
        if (!file) {
            return std::vector<uint8_t>();
        }
        file.seekg(0, std::ios::end);
        std::streamsize fileSize = file.tellg();
        file.seekg(0, std::ios::beg);
        std::vector<uint8_t> data(fileSize);
        file.read(reinterpret_cast<char*>(data.data()), fileSize);
        return data;
    } catch (const std::exception& e) {
        std::cerr << "Error in loadResource: " << e.what() << std::endl;
        return std::vector<uint8_t>();
    }
}

bool Z3Processor::saveResource(const std::string& path, const std::vector<uint8_t>& content) {
    try {
        std::ofstream out(path, std::ios::binary);
        if (!out) return false;
        out.write(reinterpret_cast<const char*>(content.data()), static_cast<std::streamsize>(content.size()));
        return out.good();
    } catch (...) {
        return false;
    }
}

std::vector<uint8_t> Z3Processor::processData(const std::vector<uint8_t>& data, bool encrypt) {
    switch (m_processMode) {
        case Fx7z9Process::Qx3r:
            return algorithmXor(data);
        case Fx7z9Process::K5bc:
            return algorithmAesCbc(data, encrypt);
        case Fx7z9Process::M2tr:
            return algorithmAesCtr(data, encrypt);
        case Fx7z9Process::Z1ha:
            return algorithmChacha20(data, encrypt);
        case Fx7z9Process::P3rc:
            return algorithmRc4(data);
        case Fx7z9Process::B2fs:
            return algorithmBlowfish(data, encrypt);
        case Fx7z9Process::T5sh:
            return algorithmTwofish(data, encrypt);
        case Fx7z9Process::S7pt:
            return algorithmSerpent(data, encrypt);
        case Fx7z9Process::C9la:
            return algorithmCamellia(data, encrypt);
        case Fx7z9Process::G4cm:
            return algorithmGcm(data, encrypt);
        case Fx7z9Process::P1y5:
            return algorithmPoly1305(data, encrypt);
        default:
            return data;
    }
}

// TODO: Implement strong cryptographic algorithms.
// Current implementations are no-op placeholders using XOR for demonstration only.

std::vector<uint8_t> Z3Processor::algorithmXor(const std::vector<uint8_t>& data) {
    std::vector<uint8_t> result = data;
    if (m_seedValue.empty()) {
        return result;
    }
    for (size_t i = 0; i < result.size(); i++) {
        result[i] ^= m_seedValue[i % m_seedValue.size()];
    }
    return result;
}

#ifdef HAVE_OPENSSL

static std::vector<uint8_t> deriveKey(const std::vector<uint8_t>& seed, size_t keyLen) {
    std::vector<uint8_t> key(keyLen, 0);
    if (seed.empty()) {
        return key;
    }
    for (size_t i = 0; i < keyLen; ++i) {
        key[i] = seed[i % seed.size()];
    }
    return key;
}

static bool evpCipherRun(const EVP_CIPHER* cipher,
                         const std::vector<uint8_t>& key,
                         const std::vector<uint8_t>& iv,
                         const std::vector<uint8_t>& input,
                         bool encrypt,
                         std::vector<uint8_t>& output) {
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if (!ctx) return false;
    bool ok = false;
    int rc = 0;
    do {
        rc = EVP_CipherInit_ex(ctx, cipher, nullptr, nullptr, nullptr, encrypt ? 1 : 0);
        if (rc != 1) break;
        if (!iv.empty()) {
            rc = EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, static_cast<int>(iv.size()), nullptr);
            if (rc != 1 && EVP_CIPHER_mode(cipher) == EVP_CIPH_GCM_MODE) break;
        }
        rc = EVP_CipherInit_ex(ctx, nullptr, nullptr, key.data(), iv.empty() ? nullptr : iv.data(), encrypt ? 1 : 0);
        if (rc != 1) break;

        output.resize(input.size() + EVP_CIPHER_block_size(cipher));
        int outLen1 = 0, outLen2 = 0;
        rc = EVP_CipherUpdate(ctx, output.data(), &outLen1, input.data(), static_cast<int>(input.size()));
        if (rc != 1) break;
        rc = EVP_CipherFinal_ex(ctx, output.data() + outLen1, &outLen2);
        if (rc != 1) break;
        output.resize(outLen1 + outLen2);
        ok = true;
    } while (false);
    EVP_CIPHER_CTX_free(ctx);
    return ok;
}

static bool evpAeadRun(const EVP_CIPHER* cipher,
                       const std::vector<uint8_t>& key,
                       const std::vector<uint8_t>& nonce,
                       const std::vector<uint8_t>& input,
                       bool encrypt,
                       std::vector<uint8_t>& output) {
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if (!ctx) return false;
    bool ok = false;
    int rc = 0;
    const int tagLen = 16;
    std::vector<uint8_t> tag(tagLen);
    do {
        rc = EVP_CipherInit_ex(ctx, cipher, nullptr, nullptr, nullptr, encrypt ? 1 : 0);
        if (rc != 1) break;
        rc = EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_SET_IVLEN, static_cast<int>(nonce.size()), nullptr);
        if (rc != 1) break;
        rc = EVP_CipherInit_ex(ctx, nullptr, nullptr, key.data(), nonce.data(), encrypt ? 1 : 0);
        if (rc != 1) break;

        output.resize(input.size());
        int outLen1 = 0, outLen2 = 0;
        rc = EVP_CipherUpdate(ctx, output.data(), &outLen1, input.data(), static_cast<int>(input.size()));
        if (rc != 1) break;
        if (encrypt) {
            rc = EVP_CipherFinal_ex(ctx, output.data() + outLen1, &outLen2);
            if (rc != 1) break;
            output.resize(outLen1 + outLen2);
            tag.resize(tagLen);
            rc = EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_GET_TAG, tagLen, tag.data());
            if (rc != 1) break;
            // Append tag
            output.insert(output.end(), tag.begin(), tag.end());
        } else {
            // Extract tag from end
            if (input.size() < static_cast<size_t>(tagLen)) break;
            std::vector<uint8_t> ct(input.begin(), input.end() - tagLen);
            std::copy(input.end() - tagLen, input.end(), tag.begin());
            // Re-run with ciphertext only
            outLen1 = 0; outLen2 = 0;
            rc = EVP_CipherUpdate(ctx, output.data(), &outLen1, ct.data(), static_cast<int>(ct.size()));
            if (rc != 1) break;
            rc = EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_SET_TAG, tagLen, tag.data());
            if (rc != 1) break;
            rc = EVP_CipherFinal_ex(ctx, output.data() + outLen1, &outLen2);
            if (rc != 1) break;
            output.resize(outLen1 + outLen2);
        }
        ok = true;
    } while (false);
    EVP_CIPHER_CTX_free(ctx);
    return ok;
}

#endif // HAVE_OPENSSL

std::vector<uint8_t> Z3Processor::algorithmAesCbc(const std::vector<uint8_t>& data, bool encrypt) {
#ifdef HAVE_OPENSSL
    const EVP_CIPHER* cipher = EVP_aes_256_cbc();
    std::vector<uint8_t> key = deriveKey(m_seedValue, 32);
    std::vector<uint8_t> iv(16);
    std::vector<uint8_t> input = data;
    std::vector<uint8_t> output;

    if (encrypt) {
        iv = getRandomNonce(16);
        if (!evpCipherRun(cipher, key, iv, input, true, output)) return algorithmXor(data);
        // Prepend IV
        output.insert(output.begin(), iv.begin(), iv.end());
        return output;
    } else {
        if (input.size() < iv.size()) return std::vector<uint8_t>();
        iv.assign(input.begin(), input.begin() + iv.size());
        std::vector<uint8_t> ct(input.begin() + iv.size(), input.end());
        if (!evpCipherRun(cipher, key, iv, ct, false, output)) return algorithmXor(data);
        return output;
    }
#else
    return algorithmXor(data);
#endif
}

std::vector<uint8_t> Z3Processor::algorithmAesCtr(const std::vector<uint8_t>& data, bool encrypt) {
#ifdef HAVE_OPENSSL
    const EVP_CIPHER* cipher = EVP_aes_256_ctr();
    std::vector<uint8_t> key = deriveKey(m_seedValue, 32);
    std::vector<uint8_t> iv(16);
    std::vector<uint8_t> input = data;
    std::vector<uint8_t> output;
    if (encrypt) {
        iv = getRandomNonce(16);
        if (!evpCipherRun(cipher, key, iv, input, true, output)) return algorithmXor(data);
        output.insert(output.begin(), iv.begin(), iv.end());
        return output;
    } else {
        if (input.size() < iv.size()) return std::vector<uint8_t>();
        iv.assign(input.begin(), input.begin() + iv.size());
        std::vector<uint8_t> ct(input.begin() + iv.size(), input.end());
        if (!evpCipherRun(cipher, key, iv, ct, false, output)) return algorithmXor(data);
        return output;
    }
#else
    return algorithmXor(data);
#endif
}

std::vector<uint8_t> Z3Processor::algorithmChacha20(const std::vector<uint8_t>& data, bool encrypt) {
#ifdef HAVE_OPENSSL
    const EVP_CIPHER* cipher = EVP_chacha20();
    std::vector<uint8_t> key = deriveKey(m_seedValue, 32);
    std::vector<uint8_t> nonce(16);
    std::vector<uint8_t> input = data;
    std::vector<uint8_t> output;
    if (encrypt) {
        nonce = getRandomNonce(16);
        if (!evpCipherRun(cipher, key, nonce, input, true, output)) return algorithmXor(data);
        output.insert(output.begin(), nonce.begin(), nonce.end());
        return output;
    } else {
        if (input.size() < nonce.size()) return std::vector<uint8_t>();
        nonce.assign(input.begin(), input.begin() + nonce.size());
        std::vector<uint8_t> ct(input.begin() + nonce.size(), input.end());
        if (!evpCipherRun(cipher, key, nonce, ct, false, output)) return algorithmXor(data);
        return output;
    }
#else
    return algorithmXor(data);
#endif
}

std::vector<uint8_t> Z3Processor::algorithmRc4(const std::vector<uint8_t>& data) {
#ifdef HAVE_OPENSSL
    const EVP_CIPHER* cipher = EVP_rc4();
    std::vector<uint8_t> key = deriveKey(m_seedValue, 16);
    std::vector<uint8_t> iv; // RC4 has no IV
    std::vector<uint8_t> output;
    if (!evpCipherRun(cipher, key, iv, data, true, output)) return algorithmXor(data);
    return output;
#else
    return algorithmXor(data);
#endif
}

std::vector<uint8_t> Z3Processor::algorithmBlowfish(const std::vector<uint8_t>& data, bool encrypt) {
#ifdef HAVE_OPENSSL
    const EVP_CIPHER* cipher = EVP_bf_cbc();
    std::vector<uint8_t> key = deriveKey(m_seedValue, 16);
    std::vector<uint8_t> iv(8);
    std::vector<uint8_t> input = data;
    std::vector<uint8_t> output;
    if (encrypt) {
        iv = getRandomNonce(8);
        if (!evpCipherRun(cipher, key, iv, input, true, output)) return algorithmXor(data);
        output.insert(output.begin(), iv.begin(), iv.end());
        return output;
    } else {
        if (input.size() < iv.size()) return std::vector<uint8_t>();
        iv.assign(input.begin(), input.begin() + iv.size());
        std::vector<uint8_t> ct(input.begin() + iv.size(), input.end());
        if (!evpCipherRun(cipher, key, iv, ct, false, output)) return algorithmXor(data);
        return output;
    }
#else
    return algorithmXor(data);
#endif
}

std::vector<uint8_t> Z3Processor::algorithmTwofish(const std::vector<uint8_t>& data, bool encrypt) {
#ifdef HAVE_CRYPTOPP
    using namespace CryptoPP;
    std::vector<uint8_t> key = m_seedValue;
    if (key.empty()) key.resize(32, 0);
    key.resize(32); // Twofish supports up to 256-bit keys
    std::vector<uint8_t> iv(16);
    std::vector<uint8_t> input = data;
    std::vector<uint8_t> output;
    try {
        if (encrypt) {
            iv = getRandomNonce(16);
            CBC_Mode<Twofish>::Encryption enc(key.data(), key.size(), iv.data());
            std::string cipher;
            StringSource ss(input.data(), input.size(), true,
                new StreamTransformationFilter(enc, new StringSink(cipher))
            );
            output.assign(iv.begin(), iv.end());
            output.insert(output.end(), cipher.begin(), cipher.end());
        } else {
            if (input.size() < iv.size()) return std::vector<uint8_t>();
            iv.assign(input.begin(), input.begin() + iv.size());
            std::vector<uint8_t> ct(input.begin() + iv.size(), input.end());
            CBC_Mode<Twofish>::Decryption dec(key.data(), key.size(), iv.data());
            std::string plain;
            StringSource ss(ct.data(), ct.size(), true,
                new StreamTransformationFilter(dec, new StringSink(plain))
            );
            output.assign(plain.begin(), plain.end());
        }
        return output;
    } catch (...) {
        return algorithmXor(data);
    }
#else
    return algorithmXor(data);
#endif
}

std::vector<uint8_t> Z3Processor::algorithmSerpent(const std::vector<uint8_t>& data, bool encrypt) {
#ifdef HAVE_CRYPTOPP
    using namespace CryptoPP;
    std::vector<uint8_t> key = m_seedValue;
    if (key.empty()) key.resize(32, 0);
    key.resize(32); // 256-bit key
    std::vector<uint8_t> iv(16);
    std::vector<uint8_t> input = data;
    std::vector<uint8_t> output;
    try {
        if (encrypt) {
            iv = getRandomNonce(16);
            CBC_Mode<Serpent>::Encryption enc(key.data(), key.size(), iv.data());
            std::string cipher;
            StringSource ss(input.data(), input.size(), true,
                new StreamTransformationFilter(enc, new StringSink(cipher))
            );
            output.assign(iv.begin(), iv.end());
            output.insert(output.end(), cipher.begin(), cipher.end());
        } else {
            if (input.size() < iv.size()) return std::vector<uint8_t>();
            iv.assign(input.begin(), input.begin() + iv.size());
            std::vector<uint8_t> ct(input.begin() + iv.size(), input.end());
            CBC_Mode<Serpent>::Decryption dec(key.data(), key.size(), iv.data());
            std::string plain;
            StringSource ss(ct.data(), ct.size(), true,
                new StreamTransformationFilter(dec, new StringSink(plain))
            );
            output.assign(plain.begin(), plain.end());
        }
        return output;
    } catch (...) {
        return algorithmXor(data);
    }
#else
    return algorithmXor(data);
#endif
}

std::vector<uint8_t> Z3Processor::algorithmCamellia(const std::vector<uint8_t>& data, bool encrypt) {
#ifdef HAVE_OPENSSL
    const EVP_CIPHER* cipher = EVP_camellia_256_cbc();
    std::vector<uint8_t> key = deriveKey(m_seedValue, 32);
    std::vector<uint8_t> iv(16);
    std::vector<uint8_t> input = data;
    std::vector<uint8_t> output;
    if (encrypt) {
        iv = getRandomNonce(16);
        if (!evpCipherRun(cipher, key, iv, input, true, output)) return algorithmXor(data);
        output.insert(output.begin(), iv.begin(), iv.end());
        return output;
    } else {
        if (input.size() < iv.size()) return std::vector<uint8_t>();
        iv.assign(input.begin(), input.begin() + iv.size());
        std::vector<uint8_t> ct(input.begin() + iv.size(), input.end());
        if (!evpCipherRun(cipher, key, iv, ct, false, output)) return algorithmXor(data);
        return output;
    }
#else
    return algorithmXor(data);
#endif
}

std::vector<uint8_t> Z3Processor::algorithmGcm(const std::vector<uint8_t>& data, bool encrypt) {
#ifdef HAVE_OPENSSL
    const EVP_CIPHER* cipher = EVP_aes_256_gcm();
    std::vector<uint8_t> key = deriveKey(m_seedValue, 32);
    std::vector<uint8_t> nonce = getRandomNonce(12);
    std::vector<uint8_t> input = data;
    std::vector<uint8_t> output;
    if (encrypt) {
        if (!evpAeadRun(cipher, key, nonce, input, true, output)) return algorithmXor(data);
        // Prepend nonce
        output.insert(output.begin(), nonce.begin(), nonce.end());
        return output;
    } else {
        if (input.size() < 12 + 16) return std::vector<uint8_t>();
        nonce.assign(input.begin(), input.begin() + 12);
        std::vector<uint8_t> ct_and_tag(input.begin() + 12, input.end());
        if (!evpAeadRun(cipher, key, nonce, ct_and_tag, false, output)) return algorithmXor(data);
        return output;
    }
#else
    return algorithmXor(data);
#endif
}

std::vector<uint8_t> Z3Processor::algorithmPoly1305(const std::vector<uint8_t>& data, bool encrypt) {
#ifdef HAVE_OPENSSL
    // Use ChaCha20-Poly1305 AEAD
    const EVP_CIPHER* cipher = EVP_chacha20_poly1305();
    std::vector<uint8_t> key = deriveKey(m_seedValue, 32);
    std::vector<uint8_t> nonce = getRandomNonce(12);
    std::vector<uint8_t> input = data;
    std::vector<uint8_t> output;
    if (encrypt) {
        if (!evpAeadRun(cipher, key, nonce, input, true, output)) return algorithmXor(data);
        output.insert(output.begin(), nonce.begin(), nonce.end());
        return output;
    } else {
        if (input.size() < 12 + 16) return std::vector<uint8_t>();
        nonce.assign(input.begin(), input.begin() + 12);
        std::vector<uint8_t> ct_and_tag(input.begin() + 12, input.end());
        if (!evpAeadRun(cipher, key, nonce, ct_and_tag, false, output)) return algorithmXor(data);
        return output;
    }
#else
    return algorithmXor(data);
#endif
}

std::vector<uint8_t> Z3Processor::getRandomNonce(size_t size) {
    std::vector<uint8_t> nonce(size);
#ifdef HAVE_OPENSSL
    if (RAND_bytes(nonce.data(), static_cast<int>(size)) == 1) {
        return nonce;
    }
#endif
    std::random_device rd;
    for (size_t i = 0; i < size; i++) {
        nonce[i] = static_cast<uint8_t>(rd());
    }
    if (!m_seedValue.empty()) {
        for (size_t i = 0; i < size && i < m_seedValue.size(); i++) {
            nonce[i] ^= m_seedValue[i];
        }
    }
    return nonce;
}

