#include "menu.h"
#include "../include/packer.h"
#include <iostream>
#include <sstream>
#include <iomanip>
#include <map>
#include "kernel_hooks.h"

#ifdef _WIN32
#include <windows.h>
#endif

// Forward declaration of KernelHookManager - will be defined in main.cpp
extern void registerProtectedMemoryRegion(DWORD processId, void* startAddress, SIZE_T size);

// Map of encryption modes
static const std::map<char, Fx7z9Process> encryptionModes = {
    {'x', Fx7z9Process::Qx3r},  // Basic XOR
    {'k', Fx7z9Process::K5bc},  // AES-CBC
    {'m', Fx7z9Process::M2tr},  // AES-CTR
    {'z', Fx7z9Process::Z1ha},  // ChaCha20
    {'p', Fx7z9Process::P3rc},  // RC4
    {'b', Fx7z9Process::B2fs},  // Blowfish
    {'t', Fx7z9Process::T5sh},  // Twofish
    {'s', Fx7z9Process::S7pt},  // Serpent
    {'c', Fx7z9Process::C9la},  // Camellia
    {'g', Fx7z9Process::G4cm},  // GCM
    {'y', Fx7z9Process::P1y5}   // Poly1305
};

void displayMenu() {
    Z3Processor processor;
    KernelHookManager hookManager;
    
    bool exitProgram = false;
    
    // Try to initialize hook manager once at startup
    bool hooksAvailable = hookManager.isKernelHookAvailable();
    if (hooksAvailable) {
        if (hookManager.initialize()) {
            std::cout << "Security hooks initialized successfully." << std::endl;
        } else {
            std::cout << "Failed to initialize security hooks." << std::endl;
            hooksAvailable = false;
        }
    }
    
    while (!exitProgram) {
        std::cout << "\n==== Encryption and Packing Tool ====\n";
        std::cout << "1. Encryption/Decryption Operations\n";
        std::cout << "2. File Packing Operations\n";
        std::cout << "3. PE File Manipulation\n";
        if (hooksAvailable) {
            std::cout << "4. Security and Protection Options\n";
        }
        std::cout << "0. Exit\n";
        std::cout << "Enter your choice: ";
        
        int choice;
        std::cin >> choice;
        
        if (choice == 0) {
            exitProgram = true;
        } else if (choice == 1) {
            displayEncryptionMenu();
            int encChoice;
            std::cin >> encChoice;
            handleEncryptionChoice(encChoice, processor);
        } else if (choice == 2) {
            displayPackingMenu();
            int packChoice;
            std::cin >> packChoice;
            handlePackingChoice(packChoice, processor);
        } else if (choice == 3) {
            displayPEMenu();
            int peChoice;
            std::cin >> peChoice;
            handlePEManipulationChoice(peChoice, processor, hookManager);
        } else if (choice == 4 && hooksAvailable) {
            displaySecurityMenu();
            int secChoice;
            std::cin >> secChoice;
            handleSecurityChoice(secChoice, hookManager);
        } else {
            std::cout << "Invalid choice. Please try again.\n";
        }
    }
    
    // Clean up hooks before exiting
    if (hooksAvailable) {
        hookManager.cleanup();
    }
    
    std::cout << "Thank you for using the Encryption and Packing Tool!\n";
}

void displayEncryptionMenu() {
    std::cout << "\n==== Encryption/Decryption Operations ====\n";
    std::cout << "1. Encrypt a file\n";
    std::cout << "2. Decrypt a file\n";
    std::cout << "3. Encrypt a folder\n";
    std::cout << "4. Decrypt a folder\n";
    std::cout << "0. Back to Main Menu\n";
    std::cout << "Enter your choice: ";
}

void handleEncryptionChoice(int choice, Z3Processor& processor) {
    if (choice == 0) {
        return;
    }
    
    bool isEncrypt = (choice == 1 || choice == 3);
    bool isFolder = (choice == 3 || choice == 4);
    
    // Select encryption algorithm
    std::cout << "\nSelect encryption algorithm:\n";
    std::cout << "x - XOR (Basic)\n";
    std::cout << "k - AES-CBC\n";
    std::cout << "m - AES-CTR\n";
    std::cout << "z - ChaCha20\n";
    std::cout << "p - RC4\n";
    std::cout << "b - Blowfish\n";
    std::cout << "t - Twofish\n";
    std::cout << "s - Serpent\n";
    std::cout << "c - Camellia\n";
    std::cout << "g - GCM (Authenticated)\n";
    std::cout << "y - Poly1305 (Authenticated)\n";
    std::cout << "Enter your choice: ";
    
    char algoChoice;
    std::cin >> algoChoice;
    
    auto modeIt = encryptionModes.find(std::tolower(algoChoice));
    if (modeIt == encryptionModes.end()) {
        std::cout << "Invalid algorithm choice. Using XOR as default.\n";
        processor.setupMode(Fx7z9Process::Qx3r);
    } else {
        processor.setupMode(modeIt->second);
    }
    
    // Get seed/key
    std::vector<uint8_t> seed = getHexSeed();
    processor.setupSeed(seed);
    
    if (isFolder) {
        // Handle folder encryption/decryption
        std::string folderPath = getInputPath(isEncrypt ? "Enter folder to encrypt: " : "Enter folder to decrypt: ");
        std::string outputPath = getInputPath("Enter output folder: ");
        
        // This functionality would need to be implemented in Z3Processor
        // For now, just show a placeholder message
        std::cout << "Folder " << (isEncrypt ? "encryption" : "decryption") << " not yet implemented.\n";
    } else {
        // Handle single file encryption/decryption
        if (isEncrypt) {
            std::string inputFile = getInputPath("Enter file to encrypt: ");
            std::string outputFile = getInputPath("Enter output file: ");
            
            std::vector<std::string> inputFiles = {inputFile};
            processor.runTask42(inputFiles, outputFile);
            
            std::cout << "File encrypted successfully.\n";
        } else {
            std::string inputFile = getInputPath("Enter file to decrypt: ");
            std::string outputDir = getInputPath("Enter output directory: ");
            
            processor.runTask67(inputFile, outputDir);
            
            std::cout << "File decrypted successfully.\n";
        }
    }
}

void displayPackingMenu() {
    std::cout << "\n==== File Packing Operations ====\n";
    std::cout << "1. Pack multiple files\n";
    std::cout << "2. Unpack files\n";
    std::cout << "3. Check package format\n";
    std::cout << "0. Back to Main Menu\n";
    std::cout << "Enter your choice: ";
}

void handlePackingChoice(int choice, Z3Processor& processor) {
    switch (choice) {
        case 0:
            return;
            
        case 1: {
            // Pack multiple files
            std::vector<std::string> files = getMultipleInputPaths();
            if (files.empty()) {
                std::cout << "No files selected for packing.\n";
                return;
            }
            
            std::string outputFile = getInputPath("Enter output package file: ");
            
            // Ask if encryption should be applied
            std::cout << "Apply encryption to the package? (y/n): ";
            char encChoice;
            std::cin >> encChoice;
            
            if (std::tolower(encChoice) == 'y') {
                // Select encryption algorithm
                std::cout << "\nSelect encryption algorithm:\n";
                std::cout << "x - XOR (Basic)\n";
                std::cout << "k - AES-CBC\n";
                std::cout << "m - AES-CTR\n";
                std::cout << "z - ChaCha20\n";
                std::cout << "p - RC4\n";
                std::cout << "b - Blowfish\n";
                std::cout << "t - Twofish\n";
                std::cout << "s - Serpent\n";
                std::cout << "c - Camellia\n";
                std::cout << "g - GCM (Authenticated)\n";
                std::cout << "y - Poly1305 (Authenticated)\n";
                std::cout << "Enter your choice: ";
                
                char algoChoice;
                std::cin >> algoChoice;
                
                auto modeIt = encryptionModes.find(std::tolower(algoChoice));
                if (modeIt == encryptionModes.end()) {
                    std::cout << "Invalid algorithm choice. Using XOR as default.\n";
                    processor.setupMode(Fx7z9Process::Qx3r);
                } else {
                    processor.setupMode(modeIt->second);
                }
                
                // Get seed/key
                std::vector<uint8_t> seed = getHexSeed();
                processor.setupSeed(seed);
            } else {
                // No encryption
                processor.setupMode(Fx7z9Process::D4t0);
            }
            
            processor.runTask42(files, outputFile);
            std::cout << "Files packed successfully into " << outputFile << std::endl;
            break;
        }
            
        case 2: {
            // Unpack files
            std::string packageFile = getInputPath("Enter package file to unpack: ");
            std::string outputDir = getInputPath("Enter output directory: ");
            
            // Ask for decryption key if needed
            std::cout << "Is the package encrypted? (y/n): ";
            char encChoice;
            std::cin >> encChoice;
            
            if (std::tolower(encChoice) == 'y') {
                // Get seed/key
                std::vector<uint8_t> seed = getHexSeed();
                processor.setupSeed(seed);
            }
            
            processor.runTask67(packageFile, outputDir);
            std::cout << "Package unpacked successfully to " << outputDir << std::endl;
            break;
        }
            
        case 3: {
            // Check package format
            std::string packageFile = getInputPath("Enter package file to check: ");
            
            if (processor.checkFormat92(packageFile)) {
                std::cout << "File has a valid package format.\n";
            } else {
                std::cout << "File does NOT have a valid package format.\n";
            }
            break;
        }
            
        default:
            std::cout << "Invalid choice.\n";
    }
}

void displayPEMenu() {
    std::cout << "\n==== PE File Manipulation ====" << "\n";
    std::cout << "1. Add component to PE file\n";
    std::cout << "2. Process component in PE file\n";
    std::cout << "3. Obfuscate import table\n";
    std::cout << "4. Obfuscate export table\n";
    std::cout << "5. Apply complete obfuscation\n";
    std::cout << "6. Generate stubs (overlay)\n";
    std::cout << "0. Back to Main Menu\n";
    std::cout << "Enter your choice: ";
}

void handlePEManipulationChoice(int choice, Z3Processor& processor, KernelHookManager& hookManager) {
    switch (choice) {
        case 0: return;
            
        case 1: {
            // Add component to PE file
            std::string peFile = getInputPath("Enter PE file path: ");
            
            if (!processor.checkFormat92(peFile)) {
                std::cout << "File does not have a valid PE format.\n";
                return;
            }
            
            std::cout << "Enter component label (max 8 chars): ";
            std::string label;
            std::cin >> label;
            
            std::string componentFile = getInputPath("Enter component data file: ");
            auto componentData = processor.loadResource(componentFile);
            
            if (componentData.empty()) {
                std::cout << "Failed to load component data.\n";
                return;
            }
            
            // Register component data memory as protected if hooks are available
            try {
                #ifdef _WIN32
                registerProtectedMemoryRegion(GetCurrentProcessId(), componentData.data(), componentData.size());
#endif
            } catch (...) {
                // Continue if protection fails
            }
            
            if (processor.task104(peFile, label, componentData)) {
                std::cout << "Component added successfully.\n";
            } else {
                std::cout << "Failed to add component.\n";
            }
            break;
        }
            
        case 2: {
            // Process component in PE file
            std::string peFile = getInputPath("Enter PE file path: ");
            
            if (!processor.checkFormat92(peFile)) {
                std::cout << "File does not have a valid PE format.\n";
                return;
            }
            
            std::cout << "Enter component label to process: ";
            std::string label;
            std::cin >> label;
            
            // Select encryption algorithm
            std::cout << "\nSelect encryption algorithm:\n";
            std::cout << "x - XOR (Basic)\n";
            std::cout << "k - AES-CBC\n";
            std::cout << "m - AES-CTR\n";
            std::cout << "z - ChaCha20\n";
            std::cout << "p - RC4\n";
            std::cout << "b - Blowfish\n";
            std::cout << "t - Twofish\n";
            std::cout << "s - Serpent\n";
            std::cout << "c - Camellia\n";
            std::cout << "g - GCM (Authenticated)\n";
            std::cout << "y - Poly1305 (Authenticated)\n";
            std::cout << "Enter your choice: ";
            
            char algoChoice;
            std::cin >> algoChoice;
            
            Fx7z9Process mode = Fx7z9Process::Qx3r;
            auto modeIt = encryptionModes.find(std::tolower(algoChoice));
            if (modeIt != encryptionModes.end()) {
                mode = modeIt->second;
            } else {
                std::cout << "Invalid algorithm choice. Using XOR as default.\n";
            }
            
            // Get seed/key
            std::vector<uint8_t> seed = getHexSeed();
            
            if (processor.task219(peFile, label, mode, seed)) {
                std::cout << "Component processed successfully.\n";
            } else {
                std::cout << "Failed to process component.\n";
            }
            break;
        }
            
        case 3: {
            // Obfuscate import table
            std::string peFile = getInputPath("Enter PE file path: ");
            
            if (!processor.checkFormat92(peFile)) {
                std::cout << "File does not have a valid PE format.\n";
                return;
            }
            
            if (processor.task317(peFile)) {
                std::cout << "Import table obfuscated successfully.\n";
            } else {
                std::cout << "Failed to obfuscate import table.\n";
            }
            break;
        }
            
        case 4: {
            // Obfuscate export table
            std::string peFile = getInputPath("Enter PE file path: ");
            
            if (!processor.checkFormat92(peFile)) {
                std::cout << "File does not have a valid PE format.\n";
                return;
            }
            
            if (processor.task318(peFile)) {
                std::cout << "Export table obfuscated successfully.\n";
            } else {
                std::cout << "Failed to obfuscate export table.\n";
            }
            break;
        }
            
        case 5: {
            // Apply complete obfuscation
            std::string peFile = getInputPath("Enter PE file path: ");
            
            if (!processor.checkFormat92(peFile)) {
                std::cout << "File does not have a valid PE format.\n";
                return;
            }
            
            bool importSuccess = processor.task317(peFile);
            bool exportSuccess = processor.task318(peFile);
            
            if (importSuccess && exportSuccess) {
                std::cout << "Complete obfuscation applied successfully.\n";
            } else {
                if (!importSuccess) {
                    std::cout << "Failed to obfuscate import table.\n";
                }
                if (!exportSuccess) {
                    std::cout << "Failed to obfuscate export table.\n";
                }
            }
            break;
        }
            
        case 6: {
            std::string peFile = getInputPath("Enter PE (.exe) file path: ");
            int count;
            std::cout << "Number of stubs to append: ";
            std::cin >> count;
            std::string prefix;
            std::cout << "Label prefix (e.g., STUB_): ";
            std::cin >> prefix;
            size_t stubSize;
            std::cout << "Stub size in bytes (default 256): ";
            std::cin >> stubSize;
            if (processor.addRandomStubs(peFile, count, prefix, stubSize)) {
                std::cout << "Stubs appended successfully.\n";
            } else {
                std::cout << "Failed to append stubs.\n";
            }
            break;
        }
            
        default:
            std::cout << "Invalid choice.\n";
    }
}

void displaySecurityMenu() {
    std::cout << "\n==== Security and Protection Options ====\n";
    std::cout << "1. Enable memory protection\n";
    std::cout << "2. Enable file access monitoring\n";
    std::cout << "3. Enhance random number generation\n";
    std::cout << "4. Protect specific memory region\n";
    std::cout << "5. Enable all security features\n";
    std::cout << "0. Back to Main Menu\n";
    std::cout << "Enter your choice: ";
}

void handleSecurityChoice(int choice, KernelHookManager& hookManager) {
    void* origFunc = NULL;
    
    switch (choice) {
        case 0:
            return;
            
        case 1: {
            // Enable memory protection
#ifdef _WIN32
            HMODULE kernel32 = GetModuleHandleA("kernel32.dll");
            if (!kernel32) {
                std::cout << "Failed to get kernel32.dll module handle.\n";
                return;
            }
            
            void* vpAddr = GetProcAddress(kernel32, "VirtualProtectEx");
            void* rpmAddr = GetProcAddress(kernel32, "ReadProcessMemory");
            void* wpmAddr = GetProcAddress(kernel32, "WriteProcessMemory");
            
            bool success = true;
            if (vpAddr) {
                success &= hookManager.installHook(vpAddr, NULL, &origFunc);
            }
            if (rpmAddr) {
                success &= hookManager.installHook(rpmAddr, NULL, &origFunc);
            }
            if (wpmAddr) {
                success &= hookManager.installHook(wpmAddr, NULL, &origFunc);
            }
            
            if (success) {
                std::cout << "Memory protection enabled successfully.\n";
            } else {
                std::cout << "Failed to enable some memory protection features.\n";
            }
#else
            std::cout << "Memory protection is only available on Windows.\n";
#endif
            break;
        }
            
        case 2: {
            // Enable file access monitoring
#ifdef _WIN32
            HMODULE kernel32 = GetModuleHandleA("kernel32.dll");
            if (!kernel32) {
                std::cout << "Failed to get kernel32.dll module handle.\n";
                return;
            }
            
            void* cfAddr = GetProcAddress(kernel32, "CreateFileW");
            
            if (cfAddr && hookManager.installHook(cfAddr, NULL, &origFunc)) {
                std::cout << "File access monitoring enabled successfully.\n";
            } else {
                std::cout << "Failed to enable file access monitoring.\n";
            }
#else
            std::cout << "File access monitoring is only available on Windows.\n";
#endif
            break;
        }
            
        case 3: {
            // Enhance random number generation
#ifdef _WIN32
            HMODULE advapi32 = GetModuleHandleA("advapi32.dll");
            if (!advapi32) {
                std::cout << "Failed to get advapi32.dll module handle.\n";
                return;
            }
            
            void* cgrAddr = GetProcAddress(advapi32, "CryptGenRandom");
            
            if (cgrAddr && hookManager.installHook(cgrAddr, NULL, &origFunc)) {
                std::cout << "Random number generation enhancement enabled successfully.\n";
            } else {
                std::cout << "Failed to enhance random number generation.\n";
            }
#else
            std::cout << "Random number generation enhancement is only available on Windows.\n";
#endif
            break;
        }
            
        case 4: {
            // Protect specific memory region
            std::cout << "Enter memory address to protect (hex): ";
            std::string addrHex;
            std::cin >> addrHex;
            
            void* addr = (void*)std::stoull(addrHex, nullptr, 16);
            
            std::cout << "Enter size of region to protect (decimal): ";
            size_t size;
            std::cin >> size;
            
            try {
                hookManager.registerProtectedMemory(addr, size);
                
                // Make sure memory protection hooks are enabled
#ifdef _WIN32
                HMODULE kernel32 = GetModuleHandleA("kernel32.dll");
                if (kernel32) {
                    void* vpAddr = GetProcAddress(kernel32, "VirtualProtectEx");
                    void* rpmAddr = GetProcAddress(kernel32, "ReadProcessMemory");
                    void* wpmAddr = GetProcAddress(kernel32, "WriteProcessMemory");
                    
                    if (vpAddr) hookManager.installHook(vpAddr, NULL, &origFunc);
                    if (rpmAddr) hookManager.installHook(rpmAddr, NULL, &origFunc);
                    if (wpmAddr) hookManager.installHook(wpmAddr, NULL, &origFunc);
                }
                
                std::cout << "Memory region protected successfully.\n";
#else
                std::cout << "Memory region protection is only available on Windows.\n";
#endif
            } catch (...) {
                std::cout << "Failed to protect memory region.\n";
            }
            break;
        }
            
        case 5: {
            // Enable all security features
            if (hookManager.installStandardHooks()) {
                std::cout << "All security features enabled successfully.\n";
            } else {
                std::cout << "Failed to enable some security features.\n";
            }
            break;
        }
            
        default:
            std::cout << "Invalid choice.\n";
    }
}

void handleMenuChoice(int choice) {
    if (choice == 0) return;

    if (choice == 1) {
        displayEncryptionMenu();
        int encChoice;
        std::cin >> encChoice;
        Z3Processor processor;
        handleEncryptionChoice(encChoice, processor);
        return;
    }

    if (choice == 2) {
        displayPackingMenu();
        int packChoice;
        std::cin >> packChoice;
        Z3Processor processor;
        handlePackingChoice(packChoice, processor);
        return;
    }

    if (choice == 3) {
        displayPEMenu();
        int peChoice;
        std::cin >> peChoice;
        Z3Processor processor;
        KernelHookManager hookManager;
        handlePEManipulationChoice(peChoice, processor, hookManager);
        return;
    }

    if (choice == 4) {
        displaySecurityMenu();
        int secChoice;
        std::cin >> secChoice;
        KernelHookManager hookManager;
        handleSecurityChoice(secChoice, hookManager);
        return;
    }

    std::cout << "Invalid choice. Please try again.\n";
}

std::string getInputPath(const std::string& prompt) {
    std::string path;
    std::cout << prompt;
    std::cin >> path;
    return path;
}

std::vector<std::string> getMultipleInputPaths() {
    std::vector<std::string> paths;
    std::string path;
    
    std::cout << "Enter file paths (type 'done' when finished):\n";
    
    while (true) {
        std::cout << "Path (or 'done'): ";
        std::cin >> path;
        
        if (path == "done") {
            break;
        }
        
        paths.push_back(path);
    }
    
    return paths;
}

std::vector<uint8_t> getHexSeed() {
    std::cout << "Enter encryption key/seed (hex, 32 chars for 16 bytes, press Enter for random): ";
    std::string seedHex;
    std::cin.ignore(); // Clear any previous input
    std::getline(std::cin, seedHex);
    
    std::vector<uint8_t> seed;
    
    if (!seedHex.empty()) {
        // Convert hex string to bytes
        for (size_t i = 0; i + 1 < seedHex.length(); i += 2) {
            std::string byteString = seedHex.substr(i, 2);
            uint8_t byte = (uint8_t)std::stoi(byteString, nullptr, 16);
            seed.push_back(byte);
        }
    }
    
    return seed;
}