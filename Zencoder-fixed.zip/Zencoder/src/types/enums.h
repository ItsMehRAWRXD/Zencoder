#pragma once

enum class FileType {
    Unknown,
    PortableExecutable,
    Archive,
    RegularFile
};