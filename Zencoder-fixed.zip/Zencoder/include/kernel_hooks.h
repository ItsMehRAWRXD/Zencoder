#pragma once

#include <cstddef>

class KernelHookManager {
public:
    bool isKernelHookAvailable() const { return false; }
    bool initialize() { return false; }
    void cleanup() {}

    bool installHook(void* /*target*/, void* /*detour*/, void** /*original*/ ) { return false; }
    bool installStandardHooks() { return false; }

    void registerProtectedMemory(void* /*addr*/, std::size_t /*size*/) {}
};