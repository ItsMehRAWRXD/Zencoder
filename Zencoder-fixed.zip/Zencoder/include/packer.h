#pragma once

#include <string>
#include <vector>
#include <cstdint>

// Windows-specific forward declarations for types when building on Windows
#ifdef _WIN32
#include <windows.h>
#else
using DWORD = unsigned long;
using SIZE_T = std::size_t;
#endif

// Obscured enumerations
enum class Fx7z9Process {
    D4t0,
    Qx3r,
    K5bc,
    M2tr,
    Z1ha,
    P3rc,
    B2fs,
    T5sh,
    S7pt,
    C9la,
    G4cm,
    P1y5
};

class Z3Processor {
public:
    Z3Processor();
    ~Z3Processor();
    
    // Configuration
    void setupSeed(const std::vector<uint8_t>& seed);
    void setupMode(Fx7z9Process mode);
    Fx7z9Process getProcessMode() const;

    // Operations
    bool runTask42(const std::vector<std::string>& sourceItems, const std::string& outputPath);
    bool runTask67(const std::string& inputPath, const std::string& outputDir);

    // PE-specific operations
    bool checkFormat92(const std::string& itemPath);
    bool task104(const std::string& targetItem, const std::string& label, 
                 const std::vector<uint8_t>& content);
    bool task219(const std::string& targetItem, const std::string& label,
                 Fx7z9Process mode, const std::vector<uint8_t>& seed);
    bool task317(const std::string& targetItem);
    bool task318(const std::string& targetItem);

    // New: generate and append multiple labeled stubs to a PE (overlay) without breaking .exe
    bool addRandomStubs(const std::string& targetExePath, int count, const std::string& labelPrefix, size_t stubSizeBytes);

    // Utilities
    std::vector<uint8_t> loadResource(const std::string& path);
    bool saveResource(const std::string& path, const std::vector<uint8_t>& content);

private:
    std::vector<uint8_t> processData(const std::vector<uint8_t>& data, bool encrypt);

    std::vector<uint8_t> algorithmXor(const std::vector<uint8_t>& data);
    std::vector<uint8_t> algorithmAesCbc(const std::vector<uint8_t>& data, bool encrypt);
    std::vector<uint8_t> algorithmAesCtr(const std::vector<uint8_t>& data, bool encrypt);
    std::vector<uint8_t> algorithmChacha20(const std::vector<uint8_t>& data, bool encrypt);
    std::vector<uint8_t> algorithmRc4(const std::vector<uint8_t>& data);
    std::vector<uint8_t> algorithmBlowfish(const std::vector<uint8_t>& data, bool encrypt);
    std::vector<uint8_t> algorithmTwofish(const std::vector<uint8_t>& data, bool encrypt);
    std::vector<uint8_t> algorithmSerpent(const std::vector<uint8_t>& data, bool encrypt);
    std::vector<uint8_t> algorithmCamellia(const std::vector<uint8_t>& data, bool encrypt);
    std::vector<uint8_t> algorithmGcm(const std::vector<uint8_t>& data, bool encrypt);
    std::vector<uint8_t> algorithmPoly1305(const std::vector<uint8_t>& data, bool encrypt);

    std::vector<uint8_t> getRandomNonce(size_t size);

private:
    Fx7z9Process m_processMode;
    std::vector<uint8_t> m_seedValue;
};